package org.sandhya.project.vehicles.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;import org.apache.log4j.Logger;


import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.sandhya.project.vehicles.Car;
import org.sandhya.project.vehicles.Truck;
import org.sandhya.project.vehicles.Vehicle;
import org.sandhya.project.vehicles.models.insurance;

public class database {
	private static Map<Long, Vehicle> vehiclesearch = new HashMap<>();
	private static Map<Long, insurance> ins = new HashMap<>();
	Logger log=Logger.getLogger("database.class");
	Context ctx = null;
	DataSource ds = null;
	Connection conn = null;
	ResultSet rs = null;
	public database(){
		try {

			ctx = new InitialContext();
			ds = (DataSource) ctx.lookup("jdbc:sqlite:sample.db");
		}

		catch (Exception e) {
			log.error(e.getMessage(),e);

		}
	}
	public String addVehicle(String type,Object o) {
 String retval="";
		if(type.equalsIgnoreCase("car")){
			Car car=(Car)o;
			String Querycar="INSERT INTO `vehicle`(`type`,`Model`,`Owner`,`speed`,doors) VALUES(?,?,?,?,?)";
			try (Connection conn = ds.getConnection()) {
				try(PreparedStatement stmt = conn.prepareStatement(Querycar)) {
					stmt.setString(1, car.getType());
					stmt.setString(2,car.getModel());
					stmt.setDouble(3, car.getSpeed());
					stmt.setString(4,car.getOwner());
					int i=0;
					i=stmt.executeUpdate();
					if(i>0)
						retval = "added Successfully";
			}
				catch(Exception e) {
					log.error(e.getMessage(),e);
				}
			}
			catch(Exception e) {
				log.error(e.getMessage(),e);
			}
		}
		else if(type.equalsIgnoreCase("truck")){
			Truck truck=(Truck)o;

			String Querytruck="INSERT INTO `vehicle`(`type`,`Model`,`Owner`,`speed`,Axile) VALUES(?,?,?,?,?)";
			try (Connection conn = ds.getConnection()) {
				try(PreparedStatement stmt = conn.prepareStatement(Querytruck)) {
					stmt.setString(1, truck.getType());
					stmt.setString(2,truck.getModel());
					stmt.setString(3,truck.getOwner());
					stmt.setDouble(4, truck.getSpeed());
					stmt.setInt(5,truck.getNumofaxels());
					int i=0;
					i=stmt.executeUpdate();
					if(i>0)
						retval= "added Successfully";
			}
				catch(Exception e) {
					log.error(e.getMessage(),e);
				}

			}
				catch(Exception e) {
					log.error(e.getMessage(),e);
				}
			}
		return retval;
		}
		

	
	public String removeVehicle(long id) {
		String retval="";
		String query="Delete from vehicle where id=? ";
		try (Connection conn = ds.getConnection()) {
			try(PreparedStatement stmt = conn.prepareStatement(query)) {
				stmt.setDouble(1, id);
				int i=0;
				i=stmt.executeUpdate();
				if(i>0)
					retval = "Item Deleted";

		}
			catch(Exception e){
				log.error(e.getMessage());
			}
		
	}
		catch(Exception e){
			log.error(e.getMessage());
		}
		return retval;
	}
	
	
	public List<Vehicle> getVehicle(String type){
		List<Vehicle> vehiclelist = new ArrayList<Vehicle>();
		String query="select type,Model,Owner,speed,doors,Axile from vehicle";
		try (Connection conn = ds.getConnection()) {
			try(PreparedStatement stmt = conn.prepareStatement(query)) {
				rs=stmt.executeQuery();
				while(rs.next()){
					if(type.equalsIgnoreCase("Car")||type.equals("All")){
						Car vehicle=new Car();
					vehicle.setType(rs.getString("type"));
					vehicle.setModel(rs.getString("Model"));
					vehicle.setSpeed(rs.getDouble("speed"));
					vehiclelist.add(vehicle);
				}
					if(type.equalsIgnoreCase("Truck")||type.equals("All")){
						Truck truck=new Truck();
						truck.setType(rs.getString("Type"));
						truck.setModel(rs.getString("Model"));
						truck.setNumofaxels(Integer.parseInt(rs.getString("Axile")));
						truck.setSpeed(rs.getDouble("speed"));
						vehiclelist.add(truck);

					}
				

		}
	}
			catch(Exception e){
				log.error(e.getMessage());
				
			}
}
		catch(Exception e){
			log.error(e.getMessage());
	}
		return  vehiclelist;
}
	 
	public List<Vehicle> getVehiclewithid(String type,String id){
		List<Vehicle> vehiclelist = new ArrayList<Vehicle>();
		String query="select type,Model,Owner,speed,doors,Axile from vehicle where id=?";
		try (Connection conn = ds.getConnection()) {
			try(PreparedStatement stmt = conn.prepareStatement(query)) {
				stmt.setString(1, id);
				rs=stmt.executeQuery();
				while(rs.next()){
					if(type.equalsIgnoreCase("Car")||type.equals("All")){
						Car vehicle=new Car();
					vehicle.setType(rs.getString("type"));
					vehicle.setModel(rs.getString("Model"));
					vehicle.setSpeed(rs.getDouble("speed"));
					vehiclelist.add(vehicle);
				}
					if(type.equalsIgnoreCase("Truck")||type.equals("All")){
						Truck truck=new Truck();
						truck.setType(rs.getString("Type"));
						truck.setModel(rs.getString("Model"));
						truck.setNumofaxels(Integer.parseInt(rs.getString("Axile")));
						truck.setSpeed(rs.getDouble("speed"));
						vehiclelist.add(truck);

					}
				

		}
	}
			catch(Exception e){
				log.error(e.getMessage());
				
			}
}
		catch(Exception e){
			log.error(e.getMessage());
	}
		return  vehiclelist;
}
}