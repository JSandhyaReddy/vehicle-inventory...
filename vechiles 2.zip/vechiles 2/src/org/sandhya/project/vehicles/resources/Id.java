package org.sandhya.project.vehicles.resources;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.sandhya.project.vehicles.Vehicle;
import org.sandhya.project.vehicles.models.Response;
import org.sandhya.project.vehicles.service.VehicleService;

@Path("/id")
public class Id {
	private static Map<Long,Vehicle> vechiles = new HashMap<Long,Vehicle>();
	VehicleService vehicle=new VehicleService();
	@GET
	@Produces(MediaType.APPLICATION_XML)

	public  List<Vehicle> getVehicle() {
		return vehicle.getAllVehicles();
	}
	
	@POST
	@Path("/add")
	public Response addVechile(Vehicle vechile) {
		Response response = new Response();
		String status= vehicle.addVehicle(vechile);
		
		response.setStatus(true);
		response.setMessage(status);
		return response;
	} 
	
	@GET
	@Path("/{id}/gettestVechile")
	public List<Vehicle> gettestVechile(@PathParam("id") String id,@PathParam("id") String type) {
		
		return vehicle.getVehicle( id, type);
	}
@GET
@Path("/{id}/deletevechile")
public Response deleteVechile(@PathParam("id") int id){
	Response response = new Response();
	if(vechiles.get(id) == null){
		response.setStatus(false);
		response.setMessage("vechile Doesn't Exists");
		return response;
	}
	vehicle.removeVehicle(id);
	response.setStatus(true);
	response.setMessage("vechile deleted successfully");
	return response;
}

	
   
	
}
