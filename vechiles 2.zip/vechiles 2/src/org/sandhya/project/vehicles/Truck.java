package org.sandhya.project.vehicles;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement

public class Truck extends Vehicle{

	int numofaxels;
	Double speed;
	public int getNumofaxels() {
		return numofaxels;
	}
	public void setNumofaxels(int numofaxels) {
		this.numofaxels = numofaxels;
	}
	public Double getSpeed() {
		return speed;
	}
	public void setSpeed(Double speed) {
		this.speed = speed;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + numofaxels;
		result = prime * result + ((speed == null) ? 0 : speed.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Truck other = (Truck) obj;
		if (numofaxels != other.numofaxels)
			return false;
		
		if (speed == null) {
			if (other.speed != null)
				return false;
		} else if (!speed.equals(other.speed))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Truck [numofaxels=" + numofaxels + ", speed=" + speed + "]";
	}
	}
