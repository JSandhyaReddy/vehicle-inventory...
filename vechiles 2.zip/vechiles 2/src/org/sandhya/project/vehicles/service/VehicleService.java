package org.sandhya.project.vehicles.service;

import java.util.List;

import org.sandhya.project.vehicles.Vehicle;
import org.sandhya.project.vehicles.database.database;;

public class VehicleService {
	database databaseobj;
	public VehicleService(){
		database databaseobj =new database();
	}
	

	public  List<Vehicle> getAllVehicles() {
		databaseobj.getVehicle("all");
		
		return databaseobj.getVehicle("all");

	}


	public String addVehicle(Vehicle v) {
		return databaseobj.addVehicle("A", v);
	}

	public List<Vehicle> getVehicle(String id,String type)
	{
		return databaseobj.getVehiclewithid(id, type);
	}
	public String removeVehicle(long id) {
		return databaseobj.removeVehicle(id);
	}
}