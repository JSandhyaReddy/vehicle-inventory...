package org.sandhya.project.vehicles;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Car extends Vehicle{
	
	String registration;
	Double speed;
	String year;
	int noofdoors;
	
	@Override
	public String toString() {
		return "Car [registration=" + registration + ", speed=" + speed + ", year=" + year + ", noofdoors=" + noofdoors
				+ ", Owner=" + Owner + "]";
	}
	public String getRegistration() {
		return registration;
	}
	public void setRegistration(String registration) {
		this.registration = registration;
	}
	
	public Double getSpeed() {
		return speed;
	}
	public void setSpeed(Double speed) {
		this.speed = speed;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Owner == null) ? 0 : Owner.hashCode());
		result = prime * result + noofdoors;
		result = prime * result + ((registration == null) ? 0 : registration.hashCode());
		result = prime * result + ((speed == null) ? 0 : speed.hashCode());
		result = prime * result + ((year == null) ? 0 : year.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Car other = (Car) obj;
		if (Owner == null) {
			if (other.Owner != null)
				return false;
		} else if (!Owner.equals(other.Owner))
			return false;
		if (noofdoors != other.noofdoors)
			return false;
		if (registration == null) {
			if (other.registration != null)
				return false;
		} else if (!registration.equals(other.registration))
			return false;
		if (speed == null) {
			if (other.speed != null)
				return false;
		} else if (!speed.equals(other.speed))
			return false;
		if (year == null) {
			if (other.year != null)
				return false;
		} else if (!year.equals(other.year))
			return false;
		return true;
	}
	
	
	
}
